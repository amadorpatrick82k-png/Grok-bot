import requests

BASE = "https://api.dexscreener.com/latest/dex"

class DexScreener:
    def __init__(self, cfg):
        self.timeout = cfg["system"]["request_timeout_seconds"]

    def discover(self):
        pairs = []
        for q in ["SOL", "BTC", "ETH"]:
            try:
                r = requests.get(
                    f"{BASE}/search",
                    params={"q": q},
                    timeout=self.timeout
                )
                r.raise_for_status()
                pairs.extend(r.json().get("pairs", []))
            except Exception as exc:
                print(f"Data warning for {q}: {exc}")
        return pairs
