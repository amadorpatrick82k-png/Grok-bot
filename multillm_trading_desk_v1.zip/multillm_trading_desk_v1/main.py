from desk import TradingDesk

if __name__ == "__main__":
    TradingDesk().run_once()
