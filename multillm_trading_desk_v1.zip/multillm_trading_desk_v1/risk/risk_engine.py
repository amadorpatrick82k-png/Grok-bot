class RiskEngine:
    def __init__(self, cfg):
        self.cfg = cfg

    def pre_trade_gate(self, candidate, size):
        if size["dollars"] <= 0:
            return {"allowed": False, "reason": "ZERO_SIZE"}

        maximum = self.cfg["paper"]["starting_bankroll"] * self.cfg["risk"]["max_position_percent"]
        if size["dollars"] > maximum:
            return {"allowed": False, "reason": "POSITION_LIMIT"}

        if candidate["liquidity_usd"] < size["dollars"] * 10:
            return {"allowed": False, "reason": "INSUFFICIENT_LIQUIDITY"}

        return {"allowed": True, "reason": "PASS"}

    def volume_exit_trigger(self, volume_h6, volume_h24):
        avg_6h = volume_h24 / 4
        if avg_6h <= 0:
            return True, 0, avg_6h
        ratio = volume_h6 / avg_6h
        return ratio < self.cfg["exit"]["volume_ratio_threshold"], ratio, avg_6h
