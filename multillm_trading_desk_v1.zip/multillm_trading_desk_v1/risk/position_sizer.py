class PositionSizer:
    def __init__(self, cfg):
        self.cfg = cfg
        self.free_cash = float(cfg["paper"]["starting_bankroll"])

    def calculate(self, candidate):
        cap = self.free_cash * self.cfg["risk"]["max_position_percent"]
        min_ticket = self.cfg["paper"]["minimum_fee"] / self.cfg["paper"]["fee_rate"]

        if cap < min_ticket:
            return {
                "dollars": 0,
                "percent_of_free_cash": 0,
                "ceiling_applied": True,
                "why": "Position ceiling is below the minimum fee-efficient ticket."
            }

        return {
            "dollars": round(cap, 2),
            "percent_of_free_cash": self.cfg["risk"]["max_position_percent"],
            "ceiling_applied": True,
            "why": "v1 uses the configured hard maximum."
        }
