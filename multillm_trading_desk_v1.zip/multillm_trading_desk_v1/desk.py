from pathlib import Path
from datetime import datetime, timezone
import json

from config_loader import load_config
from data.dexscreener import DexScreener
from agents.scan import Scanner
from agents.vet import Vetter
from risk.position_sizer import PositionSizer
from risk.risk_engine import RiskEngine
from execution.paper_executor import PaperExecutor
from models.llm_adapter import LLMAdapter

class TradingDesk:
    def __init__(self):
        self.cfg = load_config()
        self.data = DexScreener(self.cfg)
        self.llm = LLMAdapter(self.cfg)
        self.scan = Scanner(self.cfg, self.llm)
        self.vet = Vetter(self.cfg)
        self.sizer = PositionSizer(self.cfg)
        self.risk = RiskEngine(self.cfg)
        self.executor = PaperExecutor(self.cfg)

    def run_once(self):
        print("=== MULTI-LLM TRADING DESK v1 ===")
        print("MODE: PAPER")
        print("LIVE EXECUTION: DISABLED")
        markets = self.data.discover()
        candidates = self.scan.run(markets)
        print(f"SCAN candidates: {len(candidates)}")

        for candidate in candidates:
            verdict = self.vet.run(candidate)
            print(f"{candidate['symbol']}: VET={verdict['verdict']}")
            if verdict["verdict"] == "REJECT":
                continue

            size = self.sizer.calculate(candidate)
            gate = self.risk.pre_trade_gate(candidate, size)
            print(f"{candidate['symbol']}: size=${size['dollars']:.2f}, gate={gate['allowed']}")

            if gate["allowed"]:
                fill = self.executor.buy(candidate, size)
                print(f"{candidate['symbol']}: {fill['status']}")

        self._write_health()

    def _write_health(self):
        Path("data").mkdir(exist_ok=True)
        event = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "mode": "paper",
            "live_execution": False,
            "status": "healthy"
        }
        with open("data/health.jsonl", "a", encoding="utf-8") as f:
            f.write(json.dumps(event) + "\n")
