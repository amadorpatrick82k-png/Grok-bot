import os

class LLMAdapter:
    # Provider-neutral interface. v1 defaults to no LLM.
    def __init__(self, cfg):
        self.provider = os.getenv("LLM_PROVIDER", "none")

    def analyze(self, agent, payload):
        if self.provider == "none":
            return {
                "provider": "none",
                "agent": agent,
                "decision": "DETERMINISTIC_FALLBACK"
            }

        raise NotImplementedError(
            f"Provider '{self.provider}' needs its adapter implementation."
        )
