# Multi-LLM Trading Desk v1

Paper-trading-first implementation of SCAN -> VET -> BOOK -> SIZE -> FILLS -> RISK.

**Live execution is disabled in v1.**

## Run
Python 3.11+ is recommended.

```bash
python -m venv .venv
pip install -r requirements.txt
python main.py
```

The bot writes paper fills to `data/paper_trades.jsonl`.

The LLM layer is provider-neutral and defaults to deterministic mode. The strategy thresholds are in `config/strategy.yaml`.
