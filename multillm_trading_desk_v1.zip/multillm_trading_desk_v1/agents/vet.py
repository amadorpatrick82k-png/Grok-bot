class Vetter:
    def __init__(self, cfg):
        self.cfg = cfg

    def run(self, c):
        checks = []

        if c["liquidity_usd"] < self.cfg["market"]["min_liquidity_usd"]:
            return self._reject("LIQUIDITY", checks)
        checks.append("LIQUIDITY")

        if c["buy_sell_ratio"] < self.cfg["entry"]["min_buy_sell_ratio"]:
            return self._reject("BUY_SELL_RATIO", checks)
        checks.append("BUY_SELL_RATIO")

        if c["volume_h1"] <= 0:
            return self._reject("NO_VOLUME", checks)
        checks.append("VOLUME")

        return {
            "verdict": "PASS",
            "failed_check": None,
            "checks_run": checks,
            "why": "Passed v1 deterministic checks."
        }

    def _reject(self, check, checks):
        checks.append(check)
        return {
            "verdict": "REJECT",
            "failed_check": check,
            "checks_run": checks,
            "why": f"Failed {check}."
        }
