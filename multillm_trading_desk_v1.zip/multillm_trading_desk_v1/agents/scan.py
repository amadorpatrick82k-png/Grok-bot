class Scanner:
    def __init__(self, cfg, llm):
        self.cfg = cfg
        self.llm = llm

    def run(self, pairs):
        out = []
        for p in pairs:
            liq = float((p.get("liquidity") or {}).get("usd") or 0)
            vol = float((p.get("volume") or {}).get("h1") or 0)
            tx = p.get("txns") or {}
            h1 = tx.get("h1") or {}
            buys = int(h1.get("buys") or 0)
            sells = int(h1.get("sells") or 0)
            ratio = buys / max(sells, 1)

            if liq <= 0:
                continue

            score = 0
            if liq >= self.cfg["market"]["min_liquidity_usd"]:
                score += 25
            if ratio >= self.cfg["entry"]["min_buy_sell_ratio"]:
                score += 25
            if vol > 0:
                score += 25

            pc = float((p.get("priceChange") or {}).get("h1") or 0)
            if pc > 0:
                score += 25

            if score >= self.cfg["entry"]["min_scan_score"]:
                out.append({
                    "symbol": p.get("baseToken", {}).get("symbol", "?"),
                    "contract": p.get("baseToken", {}).get("address", ""),
                    "price_usd": float(p.get("priceUsd") or 0),
                    "liquidity_usd": liq,
                    "volume_h1": vol,
                    "volume_h6": float((p.get("volume") or {}).get("h6") or 0),
                    "volume_h24": float((p.get("volume") or {}).get("h24") or 0),
                    "buys_h1": buys,
                    "sells_h1": sells,
                    "buy_sell_ratio": ratio,
                    "price_change_h1": pc,
                    "score": score,
                    "pair": p
                })

        out.sort(key=lambda x: x["score"], reverse=True)
        return out[:self.cfg["system"]["max_candidates"]]
