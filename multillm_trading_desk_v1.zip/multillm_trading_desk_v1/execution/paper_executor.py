import json
from pathlib import Path
from datetime import datetime, timezone

class PaperExecutor:
    def __init__(self, cfg):
        self.cfg = cfg
        Path("data").mkdir(exist_ok=True)

    def buy(self, candidate, size):
        fee = max(
            size["dollars"] * self.cfg["paper"]["fee_rate"],
            self.cfg["paper"]["minimum_fee"]
        )

        fill = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "symbol": candidate["symbol"],
            "contract": candidate["contract"],
            "requested": size["dollars"],
            "filled": size["dollars"],
            "decision_price": candidate["price_usd"],
            "fill_price": candidate["price_usd"],
            "fee": round(fee, 4),
            "slippage_bps": 0,
            "status": "PAPER_FILLED"
        }

        with open("data/paper_trades.jsonl", "a", encoding="utf-8") as f:
            f.write(json.dumps(fill) + "\n")

        return fill
