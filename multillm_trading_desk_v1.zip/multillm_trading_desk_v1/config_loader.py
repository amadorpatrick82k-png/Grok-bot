import yaml

def load_config():
    with open("config/strategy.yaml", "r", encoding="utf-8") as f:
        return yaml.safe_load(f)
